# Install Guide (v2.3.51)

1) Upload contents of this zip to your plugin directory (overwrite files).
2) Clear caches (WordPress + browser hard refresh).
3) Verify using the Testing Checklist in CHANGELOG_APPLIED.md.
