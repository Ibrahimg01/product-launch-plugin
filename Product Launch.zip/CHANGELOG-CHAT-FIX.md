# Chat Input Full-Width Fix — CHANGELOG

- Applied on: 2025-09-20T20:57:32.789615 UTC
- File updated: `assets/css/product-launch.css`
- Backup created: `assets/css/product-launch.css.bak`
- Patch source: `/mnt/data/chat_input_fix.css`

## What changed
- Ensured `.chat-input-wrapper`, `.chat-textarea`, `.chat-form`, and `.chat-input` use `width: 100%` with `box-sizing: border-box`.
- Added `flex: 1` to textarea and `flex-shrink: 0` to send button to maintain layout.
- Kept patch at end of stylesheet so it overrides existing rules without risky regex replacements.

If you need me to inline-replace specific prior rules instead of appending (for cleaner CSS),
I can perform a targeted find/replace next.

## v2.3.1 - 2025-09-27
- Added vibrant **Beta** badges to modal title, phase headers, and dashboard banner.
- Appended CSS animations and responsive styles for badges.
- Safe JS enhancement to ensure badge injects post-render if markup differs.
- Version bumped and integrity walkthrough pending.


## v2.3.2 - 2025-09-27
- Dashboard header updated: added <h1> with **Beta** badge inside `.phase-header` after the icon.
- Ensures visual parity with phase pages; removes reliance on JS injection for dashboard badge.
- Version bump and pre-delivery walkthrough complete.


## v2.3.3 - 2025-09-27
- Centered the "Get Expert Guidance" section across all phases by adding `text-align: center` to `.ai-coach-section`.
- Added small flex centering for inner containers (`.ai-coach-inner`, `.ai-coach-actions`) for consistent alignment.
- Version bump and pre-delivery walkthrough.

\n## v2.3.4 - 2025-09-27
- Dashboard "Chat with AI" button now opens the AI coaching modal for that specific phase.
- Added delegated click handler `.quick-start-btn` in JS with safe fallbacks to set phase context.
- Updated dashboard markup to use `<button class="phase-button quick-start-btn" data-phase="$phase_key">`.
- Version bump and pre-delivery walkthrough.
\n
## v2.3.5 - 2025-09-27
- Wired **Chat with AI** buttons into the class event system: added `.quick-start-btn` handler inside `bindEvents()`.
- Keeps context-aware launch via `startCoachingSession(phase)`; includes a small safety shim if the class isn't found.
- Version bump and quick verification steps.


## v2.3.6 - 2025-09-27
- **Dashboard UX**: Removed "Chat with AI" from completed phase cards; kept a single, centered **Review** button.
- Centered card actions via inline style patch in `dashboard.php` and CSS reinforcement.
- Removed `.quick-start-btn` JS handler and safety shim since dashboard chat entry is deprecated.
- Version bump + quick walkthrough.


## v2.3.7 - 2025-09-27
- **Multisite UX/Permissions**: Settings submenu now **hidden from subsites** unless user is **Super Admin**. Remains visible to admins on single-site installs.
- Added extra permission checks inside `pl_render_settings_page()` for defense-in-depth.


## v2.3.8 - 2025-09-27
- **Network-wide settings**: API key & model now stored via `get_site_option()/update_site_option` on Multisite; single-site still uses `get_option()/update_option`.
- **Settings registration**: Only registered for Super Admins on Multisite (admins on single-site).
- **Settings page**: Clear "Network Settings" heading + notice that settings apply to all sites.
- **Network Admin menu**: Added top-level "Product Launch" under Network Admin (`manage_network_options`) to manage settings centrally.


## v2.3.9 - 2025-09-27
- Fixed **fatal redeclare** by ensuring only one `pl_sanitize_settings()` exists and wrapping settings helpers with `function_exists` guards.
- Deduped multiple `admin_init` registrations to avoid double settings registration.


## v2.3.10 - 2025-09-27
- Follow-up fix: removed lingering duplicate `pl_sanitize_settings()` and wrapped with `function_exists` guard.


## v2.3.11 - 2025-09-27
- **Multisite-only Network Settings**: Removed site-level **Settings** submenu entirely on Multisite. Settings now live **only in Network Admin** (`network_admin_menu`).
- Settings registration (`admin_init`) now runs only for **Super Admin** in **Network Admin** context (Multisite), preserving single-site admin behavior.


## v2.3.12 - 2025-09-27
- **Fix:** Network Admin settings form now posts to `edit.php?action=update` instead of `options.php` to prevent **404** on save.

\n## v2.3.13 - 2025-09-27
- Network Admin settings form now posts to `network_admin_url('edit.php?action=update')` and includes `_wp_http_referer` to redirect back to the page (prevents redirect to Network Dashboard).
- Added `settings_errors()` output to show success/error notices after saving.
\n\n## v2.3.14 - 2025-09-27
- Switched Network Admin settings form to a **custom action** (`pl_update_network_settings`) handled by `network_admin_edit_pl_update_network_settings` to stop redirects and 404s.
- Proper nonce handling (`wp_nonce_field(PL_OPTION_GROUP . '-options')`) in Network Admin; still uses `settings_fields()` on single-site.
- De-duplicated "Test API Connection" button (now shows only once).
\n
## v2.3.15 - 2025-09-27
- **Network-only settings**: Removed site-level Settings submenu entirely; settings live exclusively in **Network Admin**.
- **Network Admin menu**: Added top-level "Product Launch" pointing to a dedicated network settings page.
- **Network settings registration**: Registered a separate `pl_network_options` group for Network Admin only.
- **Saving flow**: Custom handler `network_admin_edit_update_pl_network_settings` processes saves and redirects back with `updated=true`.
- **Getter**: `pl_get_settings()` now always uses `get_site_option()` on multisite.

\n## v2.3.18 - 2025-09-27
- Network settings now **save inline** on the network settings page (no external action routing).
- Removed the `network_admin_edit_*` save handler to eliminate 500/redirect mismatches.
- Kept sections/fields rendering in Network Admin only; storage still uses `update_site_option()` via `pl_sanitize_network_settings()`.
\n