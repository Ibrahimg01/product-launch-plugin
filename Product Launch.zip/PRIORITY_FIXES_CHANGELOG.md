# Priority Fixes — 2025-10-05 18:02:30

## Implemented
- **Nonce-first order** in AJAX handlers (automatic injection for anonymous handlers).
- **Rate limiting** on AJAX per user/IP per action (default: 20 req / 60s window).
- **JSON/input size validation**: Enforces max size for `*_json`/`*_data` fields and validates JSON.
- **Duplicate JS definitions mitigation**: Per-file load guard prevents re-evaluating the same file twice.

## Notes
- If some AJAX handlers use **named functions** instead of anonymous closures, add this at the **top** of the handler manually:
```php
PL_Ajax_Guard::guard('my_action', 'nonce', 20, 60);
```
- If you want different limits per endpoint, change the third/fourth args in the call.
- JS guard is added to each non-minified JS file to skip duplicate executions if the same file is enqueued multiple times accidentally.
