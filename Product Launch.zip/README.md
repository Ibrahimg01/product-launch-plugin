# Product Launch Coach — v1.3.0

Upload this ZIP at Plugins → Add New → Upload Plugin.
- Titles removed from phase pages per new UI
- 8‑step progress component injected across phases
- Enhanced AI Auto‑Fill JS included
- Field‑assist AJAX enabled
