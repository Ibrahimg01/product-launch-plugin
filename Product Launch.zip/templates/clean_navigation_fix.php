<?php
/**
 * Clean Navigation Pattern - Fixes the messy layout
 * Apply this to all phase templates
 */
?>

<!-- CLEAN FORM ACTIONS LAYOUT -->
<div class="form-actions-clean">
    <!-- Primary Action Row -->
    <div class="primary-actions">
        <input type="submit" name="save_progress" class="button button-primary button-large save-btn" 
               value="Save <?php echo ucwords(str_replace('_', ' ', $current_phase)); ?> Progress">
    </div>
    
    <!-- Secondary Navigation Row -->
    <div class="secondary-navigation">
        <?php 
        // Phase navigation mapping
        $nav_map = array(
            'market_clarity' => array('prev' => null, 'next' => 'product-launch-offer', 'next_title' => 'Create Offer'),
            'create_offer' => array('prev' => 'product-launch-market', 'next' => 'product-launch-service', 'prev_title' => 'Market Clarity', 'next_title' => 'Create Service'),
            'create_service' => array('prev' => 'product-launch-offer', 'next' => 'product-launch-funnel', 'prev_title' => 'Create Offer', 'next_title' => 'Build Funnel'),
            'build_funnel' => array('prev' => 'product-launch-service', 'next' => 'product-launch-emailss', 'prev_title' => 'Create Service', 'next_title' => 'Email Sequences'),
            'email_sequences' => array('prev' => 'product-launch-funnel', 'next' => 'product-launch-organic', 'prev_title' => 'Build Funnel', 'next_title' => 'Organic Posts'),
            'organic_posts' => array('prev' => 'product-launch-emailss', 'next' => 'product-launch-ads', 'prev_title' => 'Email Sequences', 'next_title' => 'Facebook Ads'),
            'facebook_ads' => array('prev' => 'product-launch-organic', 'next' => 'product-launch-launch', 'prev_title' => 'Organic Posts', 'next_title' => 'Launch'),
            'launch' => array('prev' => 'product-launch-ads', 'next' => null, 'prev_title' => 'Facebook Ads')
        );
        
        $current_nav = $nav_map[$current_phase] ?? null;
        ?>
        
        <!-- Previous Phase Button -->
        <?php if ($current_nav && isset($current_nav['prev']) && $current_nav['prev']) : ?>
            <a href="<?php echo admin_url('admin.php?page=' . $current_nav['prev']); ?>" 
               class="nav-btn nav-btn-back">
                <span class="dashicons dashicons-arrow-left-alt"></span>
                <?php echo $current_nav['prev_title']; ?>
            </a>
        <?php endif; ?>
        
        <!-- Dashboard Button -->
        <a href="<?php echo admin_url('admin.php?page=product-launch'); ?>" 
           class="nav-btn nav-btn-dashboard">
            <span class="dashicons dashicons-dashboard"></span>
            Dashboard
        </a>
        
        <!-- Next Phase Button -->
        <?php if ($current_nav && isset($current_nav['next']) && $current_nav['next']) : ?>
            <a href="<?php echo admin_url('admin.php?page=' . $current_nav['next']); ?>" 
               class="nav-btn nav-btn-next <?php echo $is_completed ? 'nav-btn-primary' : ''; ?>">
                <?php echo $current_nav['next_title']; ?>
                <span class="dashicons dashicons-arrow-right-alt"></span>
            </a>
        <?php endif; ?>
    </div>
    
    <!-- Utility Actions Row -->
    <div class="utility-actions">
        <button type="button" class="utility-btn clear-fields-btn" onclick="clearAllFields()">
            <span class="dashicons dashicons-trash"></span>
            Clear All Fields
        </button>
    </div>
</div>

<style>
.form-actions-clean {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 30px;
    margin: 30px 0;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

/* Primary Actions Row */
.primary-actions {
    text-align: center;
    margin-bottom: 25px;
    padding-bottom: 25px;
    border-bottom: 1px solid #f3f4f6;
}

.save-btn {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    border: none;
    color: white;
    padding: 12px 30px;
    font-size: 16px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    min-width: 280px;
}

.save-btn:hover {
    background: linear-gradient(135deg, #2563eb, #1e40af);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
}

/* Secondary Navigation Row */
.secondary-navigation {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.nav-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    color: #475569;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.2s ease;
    min-width: 120px;
    justify-content: center;
}

.nav-btn:hover {
    background: #f1f5f9;
    border-color: #cbd5e1;
    transform: translateY(-1px);
    color: #334155;
}

.nav-btn-back {
    border-color: #d1d5db;
}

.nav-btn-dashboard {
    background: #fefefe;
    border-color: #d1d5db;
    font-weight: 600;
}

.nav-btn-next {
    border-color: #10b981;
    color: #059669;
}

.nav-btn-primary {
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    border-color: #10b981;
}

.nav-btn-primary:hover {
    background: linear-gradient(135deg, #059669, #047857);
    color: white;
}

/* Utility Actions Row */
.utility-actions {
    text-align: center;
    padding-top: 20px;
    border-top: 1px solid #f3f4f6;
}

.utility-btn {
    background: none;
    border: 1px solid #e5e7eb;
    color: #6b7280;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.utility-btn:hover {
    background: #f9fafb;
    border-color: #d1d5db;
    color: #374151;
}

.clear-fields-btn:hover {
    border-color: #dc2626;
    color: #dc2626;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .form-actions-clean {
        padding: 20px;
    }
    
    .secondary-navigation {
        flex-direction: column;
        gap: 10px;
    }
    
    .nav-btn {
        width: 100%;
        max-width: 280px;
    }
    
    .save-btn {
        width: 100%;
        max-width: 280px;
    }
}

/* Clean up any existing messy styles */
.form-actions {
    display: none !important;
}
</style>

<script>
function clearAllFields() {
    if (confirm('Are you sure you want to clear all fields? This action cannot be undone.')) {
        // Clear all textarea and input fields
        document.querySelectorAll('.ai-fillable').forEach(function(field) {
            field.value = '';
            field.classList.remove('ai-filled');
        });
        
        // Show success message
        const notice = document.createElement('div');
        notice.className = 'notice notice-success is-dismissible';
        notice.innerHTML = '<p>All fields cleared successfully!</p>';
        document.querySelector('.wrap').insertBefore(notice, document.querySelector('.phase-header').nextSibling);
        
        // Remove notice after 3 seconds
        setTimeout(() => {
            notice.remove();
        }, 3000);
    }
}
</script>